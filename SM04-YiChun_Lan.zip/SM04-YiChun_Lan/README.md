## SM04 -Yichun Lan

![螢幕錄影 2023-11-15 下午8 38 07](https://github.com/yclanlan/2023-Fall-SeeingMachine/assets/97862198/9614653d-f695-4f27-b864-6a3ce04a00da)
Lily and I work on the same project from our assignment 3! 
Try to let two applications can communicate with each other this time.

So the first thing we did was sending the mouseclick's X and Y from the sender to the receiver (by the OSC) and we want to send back the contour back but fail!
(We work seperately so we can both practice the code!)

And it is interesting to deal with the mouse click! Get the mouseclick X and Y first,
then send the data as the parameters in the mousePressed function!

=====
Lily asked for Elie's help! So we will test draw the counter to the fbo!
[Lily's post](https://github.com/LilYuuu/seeing-machines)