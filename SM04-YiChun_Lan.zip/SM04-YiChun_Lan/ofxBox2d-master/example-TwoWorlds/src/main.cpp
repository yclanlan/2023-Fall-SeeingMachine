#include "ofMain.h"
#include "ofApp.h"

//========================================================================
int main( ){
	ofSetupOpenGL(1000, 500, OF_WINDOW);
	ofRunApp(new ofApp());
}
